
function Event(evType, data){
	this.eventType = evType;
	this.data = data;
}
Event.COMPLETE = "COMPLETE";
Event.WINDOW_RESIZE = "WINDOW_RESIZE";
Event.WINDOW_LOCATION_CHANGE = "WINDOW_LOCATION_CHANGE";
